NOTE:

I am aware there are many warnings when running my program.  They do not affect my program's compiling or running.  

I am under the impression that having warnings are okay as long as the program runs/compiles.

I have tried, and succeeded, in fixing many of the warnings, but due to the deadline I am submitting the assignment with some.  

Please e-mail me if there are any questions at shoemakd@oregonstate.edu.
