To compile program:
run: "gcc -o smallsh smallsh.c" in the terminal, in the directory that the program is in.

to run the program:
run: "./smallsh" again, in the terminal, in the directory that the program is in.


